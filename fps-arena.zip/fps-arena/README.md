# FPS Arena — شوتر آنلاین چندنفره

## ساختار
```
fps-arena/
├─ package.json
├─ server/
│  ├─ server.js   (Node + Express + Socket.IO — منطق بازی و سرور معتبر)
│  └─ map.js      (نقشه سه‌بعدی: ساختمان، دیوار، جعبه)
└─ public/
   ├─ index.html  (منو + لابی + HUD)
   ├─ style.css
   └─ game.js     (Three.js، کنترل‌ها، شبکه)
```

## اجرا روی کامپیوتر
نیازمند Node.js نسخه 18 یا بالاتر.
```
cd fps-arena
npm install
npm start
```
مرورگر: http://localhost:3000
برای تست، دو تب باز کنید: در یکی اتاق بسازید، در دیگری با کد وارد شوید.
دوستان در همان شبکه Wi-Fi: http://IP-کامپیوتر-شما:3000

## انتشار رایگان روی Render
1. پوشه را در یک مخزن GitHub بگذارید (node_modules نباید آپلود شود).
2. در render.com: New → Web Service → اتصال مخزن.
3. Runtime: Node — Build Command: `npm install` — Start Command: `npm start` — Instance Type: Free.
4. بعد از Deploy آدرس مثل https://نام-شما.onrender.com ساخته می‌شود.
5. وارد آدرس شوید، اتاق بسازید و «کپی لینک» را برای دوستان بفرستید.

نکته: پلن رایگان بعد از چند دقیقه بی‌استفاده می‌خوابد و اولین بازشدن حدود یک دقیقه طول می‌کشد.
