(() => {
'use strict';
const $ = id => document.getElementById(id);
const socket = io();
const C = { EYE: 1.6, H: 1.75, R: 0.4, WALK: 5, RUN: 8.5, GRAV: 22, JUMP: 8, FIRE_MS: 110 };

let myId = null, inGame = false, alive = false, locked = false, firing = false, isHost = false;
const S = { hp: 100, mag: 30, reserve: 90, reloading: false, kills: 0 };
let scores = [], limit = 20, bound = 39.5, solids = [], lastFire = 0, lastTime = performance.now();
const keys = {};
const pos = new THREE.Vector3(), vel = new THREE.Vector3();
let yaw = 0, pitch = 0, onGround = false, recoil = 0, bob = 0;

/* ---------- منو و لابی ---------- */
socket.on('connect', () => { myId = socket.id; });
const nameInput = $('name');
nameInput.value = localStorage.getItem('fps_name') || '';
const urlRoom = new URLSearchParams(location.search).get('room');
if (urlRoom) $('code').value = urlRoom.toUpperCase().slice(0, 4);
function show(id) { ['menu', 'lobby', 'game'].forEach(s => $(s).classList.toggle('hidden', s !== id)); }
const err = m => { $('menuErr').textContent = m || ''; };
function getName() { const n = nameInput.value.trim(); localStorage.setItem('fps_name', n); return n; }
$('createBtn').onclick = () => socket.emit('createRoom', { name: getName() }, r => { if (!r.ok) err(r.error); });
$('joinBtn').onclick = () => {
  const c = $('code').value.trim().toUpperCase();
  if (c.length < 4) return err('کد اتاق را وارد کنید');
  socket.emit('joinRoom', { name: getName(), code: c }, r => { if (!r.ok) err(r.error); });
};
$('startBtn').onclick = () => socket.emit('startGame');
$('leaveBtn').onclick = () => { socket.emit('leaveRoom'); show('menu'); };
$('copyBtn').onclick = () => { $('shareLink').select(); navigator.clipboard && navigator.clipboard.writeText($('shareLink').value); $('copyBtn').textContent = 'کپی شد ✓'; setTimeout(() => $('copyBtn').textContent = 'کپی لینک', 1500); };
$('backBtn').onclick = () => { $('gameover').classList.add('hidden'); inGame = false; show('lobby'); };

socket.on('lobby', d => {
  isHost = d.hostId === socket.id;
  if (!inGame) show('lobby');
  $('roomCode').textContent = d.code;
  $('shareLink').value = location.origin + '/?room=' + d.code;
  const ul = $('players'); ul.innerHTML = '';
  d.players.forEach(p => {
    const li = document.createElement('li');
    const a = document.createElement('span'); a.textContent = p.name + (p.id === socket.id ? ' (شما)' : '');
    const b = document.createElement('small'); b.textContent = p.id === d.hostId ? 'میزبان' : '';
    li.append(a, b); ul.appendChild(li);
  });
  $('startBtn').classList.toggle('hidden', !isHost);
  $('waitMsg').classList.toggle('hidden', isHost);
});

/* ---------- Three.js ---------- */
let renderer, scene, camera, mapGroup, gun, flash, ready = false;
const remotes = new Map(), effects = [];

function initThree() {
  renderer = new THREE.WebGLRenderer({ canvas: $('canvas'), antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87a7c4);
  scene.fog = new THREE.Fog(0x87a7c4, 40, 120);
  camera = new THREE.PerspectiveCamera(75, 1, 0.05, 200);
  camera.rotation.order = 'YXZ';
  scene.add(camera);
  scene.add(new THREE.HemisphereLight(0xdbe9ff, 0x4a4036, 0.85));
  const sun = new THREE.DirectionalLight(0xffffff, 0.8);
  sun.position.set(30, 50, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -55, right: 55, top: 55, bottom: -55, near: 1, far: 140 });
  scene.add(sun);

  const cv = document.createElement('canvas'); cv.width = cv.height = 256;
  const g = cv.getContext('2d'); g.fillStyle = '#3d4a3a'; g.fillRect(0, 0, 256, 256);
  g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 2; g.strokeRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(cv); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(40, 40);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(82, 82), new THREE.MeshStandardMaterial({ map: tex, roughness: 1 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

  // اسلحه روی دوربین (First Person)
  gun = new THREE.Group();
  const gm = c => new THREE.MeshStandardMaterial({ color: c, roughness: .5, metalness: .4, depthTest: false });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.11, 0.5), gm(0x1f2937));
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, 0.3), gm(0x0b0f14)); barrel.position.set(0, 0.02, -0.38);
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.14, 0.07), gm(0x374151)); grip.position.set(0, -0.11, 0.1); grip.rotation.x = 0.25;
  const mag = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.08), gm(0x2ee6a6)); mag.position.set(0, -0.12, -0.08);
  gun.add(body, barrel, grip, mag);
  flash = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffd36b, depthTest: false }));
  flash.position.set(0, 0.02, -0.58); flash.visible = false; gun.add(flash);
  gun.children.forEach(m => m.renderOrder = 999);
  gun.position.set(0.22, -0.2, -0.45);
  camera.add(gun);
  resize(); addEventListener('resize', resize);
  ready = true;
}
function resize() { if (!renderer) return; renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }

function buildMap(map) {
  if (mapGroup) scene.remove(mapGroup);
  mapGroup = new THREE.Group();
  bound = map.bounds;
  solids = map.boxes.map(b => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), new THREE.MeshStandardMaterial({ color: b.c, roughness: .85 }));
    m.position.set(b.x, b.y + b.h / 2, b.z); m.castShadow = m.receiveShadow = true; mapGroup.add(m);
    return { minx: b.x - b.w / 2, maxx: b.x + b.w / 2, miny: b.y, maxy: b.y + b.h, minz: b.z - b.d / 2, maxz: b.z + b.d / 2 };
  });
  scene.add(mapGroup);
}

function label(text) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const x = c.getContext('2d'); x.font = 'bold 30px sans-serif'; x.textAlign = 'center';
  x.fillStyle = '#fff'; x.shadowColor = '#000'; x.shadowBlur = 6; x.fillText(text, 128, 42);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true }));
  s.scale.set(2, 0.5, 1); s.position.y = 2.15; return s;
}
function hash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
function makeRemote(p) {
  const g = new THREE.Group();
  const M = c => new THREE.MeshStandardMaterial({ color: c, roughness: .7 });
  const parts = [
    [new THREE.BoxGeometry(0.6, 0.8, 0.35), M(new THREE.Color().setHSL((hash(p.id) % 360) / 360, .65, .5)), 0, 1.0, 0],
    [new THREE.BoxGeometry(0.5, 0.6, 0.3), M(0x222831), 0, 0.3, 0],
    [new THREE.BoxGeometry(0.3, 0.3, 0.3), M(0xf1c8a0), 0, 1.6, 0],
    [new THREE.BoxGeometry(0.08, 0.1, 0.6), M(0x111111), 0.3, 1.1, -0.4]
  ];
  parts.forEach(([geo, mat, x, y, z]) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; g.add(m); });
  g.add(label(p.n));
  g.position.set(p.x, p.y, p.z); scene.add(g);
  return { group: g, target: new THREE.Vector3(p.x, p.y, p.z), yaw: p.yw };
}

/* ---------- صدا ---------- */
let AC;
function audio() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } return AC; }
function tone(f, d, type, v, to) {
  const a = audio(); if (!a) return;
  const o = a.createOscillator(), g = a.createGain(); o.type = type || 'square';
  o.frequency.setValueAtTime(f, a.currentTime);
  if (to) o.frequency.exponentialRampToValueAtTime(to, a.currentTime + d);
  g.gain.setValueAtTime(v, a.currentTime); g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + d);
  o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + d);
}
function noise(d, v) {
  const a = audio(); if (!a) return;
  const b = a.createBuffer(1, a.sampleRate * d, a.sampleRate), ch = b.getChannelData(0);
  for (let i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / ch.length);
  const s = a.createBufferSource(), g = a.createGain(); g.gain.value = v; s.buffer = b; s.connect(g); g.connect(a.destination); s.start();
}
const sfxShot = v => { noise(0.09, v * 0.35); tone(170, 0.12, 'sawtooth', v * 0.25, 50); };

/* ---------- ورودی ---------- */
addEventListener('keydown', e => {
  if (!inGame) return;
  keys[e.code] = true;
  if (['Space', 'Tab'].includes(e.code)) e.preventDefault();
  if (e.code === 'Tab') { renderScoreboard($('sbTable'), scores.map(p => ({ id: p.id, name: p.n, k: p.k, d: p.d }))); $('scoreboard').classList.remove('hidden'); }
  if (e.code === 'KeyR' && locked && alive) { socket.emit('reload'); tone(300, 0.05, 'square', 0.08); }
});
addEventListener('keyup', e => { keys[e.code] = false; if (e.code === 'Tab') $('scoreboard').classList.add('hidden'); });
addEventListener('mousemove', e => {
  if (!locked || !alive) return;
  yaw -= e.movementX * 0.0022; pitch = Math.max(-1.5, Math.min(1.5, pitch - e.movementY * 0.0022));
});
addEventListener('mousedown', e => { if (e.button === 0 && locked) { firing = true; audio(); } });
addEventListener('mouseup', e => { if (e.button === 0) firing = false; });
addEventListener('blur', () => { firing = false; for (const k in keys) keys[k] = false; });
$('pause').onclick = () => { audio(); $('canvas').requestPointerLock(); };
document.addEventListener('pointerlockchange', () => {
  locked = document.pointerLockElement === $('canvas');
  if (!locked) firing = false;
  $('pause').classList.toggle('hidden', locked || !inGame || !alive || !$('gameover').classList.contains('hidden'));
});

/* ---------- فیزیک و برخورد (سمت کلاینت، با تأیید سرور) ---------- */
function hits(px, py, pz) {
  for (const s of solids) {
    if (px + C.R > s.minx && px - C.R < s.maxx && pz + C.R > s.minz && pz - C.R < s.maxz && py + C.H > s.miny && py < s.maxy) return s;
  }
  return null;
}
function move(dt) {
  const f = (keys.KeyW ? 1 : 0) - (keys.KeyS ? 1 : 0), r = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0);
  const running = keys.ShiftLeft || keys.ShiftRight;
  const sp = running && f > 0 ? C.RUN : (running ? C.RUN * 0.8 : C.WALK);
  let wx = -Math.sin(yaw) * f + Math.cos(yaw) * r, wz = -Math.cos(yaw) * f - Math.sin(yaw) * r;
  const l = Math.hypot(wx, wz); if (l > 0) { wx /= l; wz /= l; }
  const k = onGround ? 1 : 0.35, a = Math.min(1, dt * 12 * k + (onGround ? 0 : 0.02));
  vel.x += (wx * sp - vel.x) * a; vel.z += (wz * sp - vel.z) * a;
  vel.y -= C.GRAV * dt;
  if (keys.Space && onGround) { vel.y = C.JUMP; onGround = false; }
  let nx = pos.x + vel.x * dt; if (!hits(nx, pos.y, pos.z)) pos.x = nx; else vel.x = 0;
  let nz = pos.z + vel.z * dt; if (!hits(pos.x, pos.y, nz)) pos.z = nz; else vel.z = 0;
  onGround = false;
  pos.y += vel.y * dt;
  const h = hits(pos.x, pos.y, pos.z);
  if (h) { if (vel.y < 0) { pos.y = h.maxy; onGround = true; } else pos.y = h.miny - C.H - 0.001; vel.y = 0; }
  if (pos.y <= 0) { pos.y = 0; vel.y = 0; onGround = true; }
  pos.x = Math.max(-bound, Math.min(bound, pos.x)); pos.z = Math.max(-bound, Math.min(bound, pos.z));
  if (l > 0 && onGround) bob += dt * sp * 1.6;
  return running && f > 0;
}

/* ---------- شبکه ---------- */
socket.on('gameStart', d => {
  if (!ready) initThree();
  buildMap(d.map); limit = d.limit; $('limit').textContent = limit;
  remotes.forEach(r => scene.remove(r.group)); remotes.clear();
  inGame = true; alive = false; show('game');
  $('gameover').classList.add('hidden'); $('death').classList.add('hidden');
  $('pause').classList.remove('hidden');
});
socket.on('spawned', d => {
  pos.set(d.x, d.y, d.z); vel.set(0, 0, 0); yaw = d.yaw; pitch = 0; alive = true;
  S.hp = 100; $('death').classList.add('hidden');
  if (!locked) $('pause').classList.remove('hidden');
});
socket.on('correct', d => { pos.set(d.x, d.y, d.z); vel.set(0, 0, 0); });
socket.on('ammo', d => { S.mag = d.mag; S.reserve = d.reserve; S.reloading = d.reloading; });
socket.on('snap', d => {
  if (!inGame) return;
  scores = d.p; const seen = new Set();
  for (const p of d.p) {
    if (p.id === myId) { S.hp = p.hp; S.kills = p.k; continue; }
    seen.add(p.id);
    let r = remotes.get(p.id); if (!r) { r = makeRemote(p); remotes.set(p.id, r); }
    r.target.set(p.x, p.y, p.z); r.yaw = p.yw; r.group.visible = p.a;
  }
  for (const [id, r] of remotes) if (!seen.has(id)) { scene.remove(r.group); remotes.delete(id); }
});
socket.on('shot', d => {
  const from = new THREE.Vector3(d.f[0], d.f[1] - 0.25, d.f[2]), to = new THREE.Vector3(...d.t);
  const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([from, to]), new THREE.LineBasicMaterial({ color: 0xffe08a }));
  scene.add(line); effects.push({ obj: line, until: performance.now() + 70 });
  const spark = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6), new THREE.MeshBasicMaterial({ color: d.h ? 0xff4d4d : 0xffd36b }));
  spark.position.copy(to); scene.add(spark); effects.push({ obj: spark, until: performance.now() + 150 });
  if (d.id !== myId) sfxShot(Math.max(0, 1 - from.distanceTo(camera.position) / 50) * 0.8);
});
function pulse(el, op) {
  el.style.transition = 'none'; el.style.opacity = op;
  requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transition = 'opacity .5s'; el.style.opacity = 0; }));
}
socket.on('hit', d => { pulse($('hitmarker'), 1); $('hitmarker').style.filter = d.kill ? 'drop-shadow(0 0 4px red) hue-rotate(150deg)' : 'none'; tone(d.head ? 1400 : 900, 0.07, 'sine', 0.12); });
socket.on('damaged', d => { S.hp = d.hp; pulse($('vignette'), 1); tone(120, 0.15, 'sawtooth', 0.15, 60); });
socket.on('died', d => {
  alive = false; firing = false; $('deathBy').textContent = 'توسط ' + d.by; $('death').classList.remove('hidden');
  let t = Math.round(d.ms / 1000); $('deathT').textContent = t;
  const iv = setInterval(() => { t--; $('deathT').textContent = Math.max(t, 0); if (t <= 0 || alive) clearInterval(iv); }, 1000);
});
socket.on('kill', d => {
  const el = document.createElement('div');
  const a = document.createElement('b'), v = document.createElement('i');
  a.textContent = d.killer; v.textContent = d.victim;
  el.append(a, document.createTextNode(d.head ? '  ⌖  ' : '  ➜  '), v);
  const kf = $('killfeed'); kf.appendChild(el); while (kf.children.length > 5) kf.firstChild.remove();
  setTimeout(() => el.remove(), 5000);
});
function renderScoreboard(table, rows) {
  rows = rows.slice().sort((a, b) => b.k - a.k || a.d - b.d);
  table.innerHTML = '';
  const hr = table.insertRow(); ['بازیکن', 'کشته', 'مرگ'].forEach(t => { const th = document.createElement('th'); th.textContent = t; hr.appendChild(th); });
  rows.forEach(r => {
    const tr = table.insertRow(); if (r.id === myId) tr.className = 'me';
    [r.name, r.k, r.d].forEach(v => tr.insertCell().textContent = v);
  });
}
socket.on('gameOver', d => {
  alive = false; firing = false; document.exitPointerLock();
  $('winner').textContent = '🏆 برنده: ' + d.winner;
  renderScoreboard($('goTable'), d.scores.map(s => ({ name: s.name, k: s.k, d: s.d })));
  $('gameover').classList.remove('hidden'); $('death').classList.add('hidden'); $('pause').classList.add('hidden');
});
setInterval(() => {
  if (inGame && alive && locked) socket.emit('state', { x: +pos.x.toFixed(3), y: +pos.y.toFixed(3), z: +pos.z.toFixed(3), yaw: +yaw.toFixed(4), pitch: +pitch.toFixed(4) });
}, 50);

/* ---------- حلقه اصلی ---------- */
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - lastTime) / 1000); lastTime = now;
  if (!inGame || !ready) return;
  let sprint = false;
  if (alive && locked) {
    sprint = move(dt);
    if (firing && now - lastFire >= C.FIRE_MS && !S.reloading && S.mag > 0) {
      lastFire = now; S.mag--; recoil = 1;
      socket.emit('shoot', { yaw, pitch }); sfxShot(1);
      flash.visible = true; setTimeout(() => flash.visible = false, 40);
    } else if (firing && S.mag === 0 && now - lastFire > 300) { lastFire = now; tone(200, 0.04, 'square', 0.05); }
  }
  camera.position.set(pos.x, pos.y + (alive ? C.EYE + Math.sin(bob) * 0.03 : 0.35), pos.z);
  camera.rotation.set(alive ? pitch : -0.3, yaw, alive ? 0 : 0.5);
  camera.fov += ((sprint ? 82 : 75) - camera.fov) * Math.min(1, dt * 8); camera.updateProjectionMatrix();
  recoil = Math.max(0, recoil - dt * 9);
  gun.position.set(0.22 + Math.sin(bob * 0.5) * 0.008, -0.2 + Math.abs(Math.cos(bob)) * 0.01 - (S.reloading ? 0.12 : 0), -0.45 + recoil * 0.06);
  gun.rotation.x = recoil * 0.06 + (S.reloading ? -0.6 : 0);
  gun.visible = alive;

  for (const r of remotes.values()) {
    r.group.position.lerp(r.target, 1 - Math.exp(-dt * 15));
    let dy = ((r.yaw - r.group.rotation.y + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
    r.group.rotation.y += dy * Math.min(1, dt * 15);
  }
  for (let i = effects.length - 1; i >= 0; i--) if (now > effects[i].until) { scene.remove(effects[i].obj); effects.splice(i, 1); }

  $('hpbar').style.width = Math.max(0, S.hp) + '%'; $('hpnum').textContent = Math.max(0, Math.ceil(S.hp));
  $('mag').textContent = S.mag; $('reserve').textContent = S.reserve; $('myKills').textContent = S.kills;
  $('reloadmsg').style.visibility = S.reloading ? 'visible' : 'hidden';
  renderer.render(scene, camera);
}
requestAnimationFrame(loop);
})();
