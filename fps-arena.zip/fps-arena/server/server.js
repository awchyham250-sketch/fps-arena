'use strict';
const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const { boxes, spawns, BOUNDS } = require('./map');

const CFG = {
  MAX_PLAYERS: 8, HP: 100, MAG: 30, RESERVE: 90, DMG: 22, HEAD_MULT: 2,
  FIRE_MS: 110, RELOAD_MS: 1800, RESPAWN_MS: 3000, KILL_LIMIT: 20,
  EYE: 1.6, HEIGHT: 1.8, HIT_R: 0.5, RUN: 8.5, INVULN_MS: 2000, TICK_MS: 50
};

const solids = boxes.map(b => ({
  minx: b.x - b.w / 2, maxx: b.x + b.w / 2, miny: b.y, maxy: b.y + b.h,
  minz: b.z - b.d / 2, maxz: b.z + b.d / 2
}));

const app = express();
const server = http.createServer(app);
const io = new Server(server, { pingInterval: 10000, pingTimeout: 20000 });
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('/health', (req, res) => res.send('ok'));

const rooms = new Map();
const where = new Map(); // socket.id -> roomCode

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const num = v => typeof v === 'number' && Number.isFinite(v);
const sanitize = n => String(n || '').replace(/[<>&"'`]/g, '').trim().slice(0, 14) || 'Player' + Math.floor(Math.random() * 900 + 100);

function genCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c;
  do { c = Array.from({ length: 4 }, () => A[Math.floor(Math.random() * A.length)]).join(''); } while (rooms.has(c));
  return c;
}

function inSolid(x, y, z) { // قد و شعاع کوچک‌تر از کلاینت، تا خطای مرزی ایجاد نشود
  const r = 0.3;
  for (const s of solids) {
    if (x + r > s.minx && x - r < s.maxx && z + r > s.minz && z - r < s.maxz && y + 1.7 > s.miny && y + 0.05 < s.maxy) return true;
  }
  return false;
}

function rayAABB(o, d, mn, mx) {
  let tmin = 0, tmax = Infinity;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) { if (o[i] < mn[i] || o[i] > mx[i]) return null; }
    else {
      let t1 = (mn[i] - o[i]) / d[i], t2 = (mx[i] - o[i]) / d[i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}

function lobbyInfo(room) {
  return { code: room.code, hostId: room.hostId, state: room.state, max: CFG.MAX_PLAYERS,
    players: [...room.players.values()].map(p => ({ id: p.id, name: p.name })) };
}
const sendLobby = room => io.to(room.code).emit('lobby', lobbyInfo(room));

function newPlayer(id, name) {
  return { id, name, x: 0, y: 0, z: 0, yaw: 0, pitch: 0, hp: CFG.HP, alive: false, kills: 0, deaths: 0,
    mag: CFG.MAG, reserve: CFG.RESERVE, reloading: false, lastShot: 0, lastState: Date.now(),
    invulnUntil: 0, reloadTimer: null, respawnTimer: null };
}

function spawnPlayer(room, p) {
  clearTimeout(p.reloadTimer); clearTimeout(p.respawnTimer);
  const others = [...room.players.values()].filter(o => o.id !== p.id && o.alive);
  let best = [], bestD = -1;
  const scored = spawns.map(s => ({ s, d: others.length ? Math.min(...others.map(o => Math.hypot(o.x - s.x, o.z - s.z))) : Math.random() * 10 }));
  scored.sort((a, b) => b.d - a.d);
  best = scored.slice(0, 3);
  const s = best[Math.floor(Math.random() * best.length)].s;
  Object.assign(p, { x: s.x, y: s.y, z: s.z, hp: CFG.HP, alive: true, mag: CFG.MAG, reserve: CFG.RESERVE,
    reloading: false, invulnUntil: Date.now() + CFG.INVULN_MS, lastState: Date.now() });
  io.to(p.id).emit('spawned', { x: p.x, y: p.y, z: p.z, yaw: Math.atan2(s.x, s.z) });
  io.to(p.id).emit('ammo', { mag: p.mag, reserve: p.reserve, reloading: false });
}

function startReload(room, p) {
  if (p.reloading || !p.alive || p.mag >= CFG.MAG || p.reserve <= 0) return;
  p.reloading = true;
  io.to(p.id).emit('ammo', { mag: p.mag, reserve: p.reserve, reloading: true });
  p.reloadTimer = setTimeout(() => {
    if (!p.alive) return;
    const n = Math.min(CFG.MAG - p.mag, p.reserve);
    p.mag += n; p.reserve -= n; p.reloading = false;
    io.to(p.id).emit('ammo', { mag: p.mag, reserve: p.reserve, reloading: false });
  }, CFG.RELOAD_MS);
}

function endGame(room, winner) {
  room.state = 'lobby';
  const scores = [...room.players.values()].map(p => ({ name: p.name, k: p.kills, d: p.deaths })).sort((a, b) => b.k - a.k);
  for (const p of room.players.values()) { clearTimeout(p.reloadTimer); clearTimeout(p.respawnTimer); p.alive = false; }
  io.to(room.code).emit('gameOver', { winner: winner.name, scores });
  sendLobby(room);
}

function removePlayer(socketId) {
  const code = where.get(socketId);
  where.delete(socketId);
  const room = rooms.get(code);
  if (!room) return;
  const p = room.players.get(socketId);
  if (p) { clearTimeout(p.reloadTimer); clearTimeout(p.respawnTimer); }
  room.players.delete(socketId);
  const s = io.sockets.sockets.get(socketId);
  if (s) s.leave(code);
  if (room.players.size === 0) { rooms.delete(code); return; }
  if (room.hostId === socketId) room.hostId = room.players.keys().next().value;
  sendLobby(room);
}

function joinRoom(socket, room, name) {
  removePlayer(socket.id);
  const p = newPlayer(socket.id, name);
  room.players.set(socket.id, p);
  where.set(socket.id, room.code);
  socket.join(room.code);
  sendLobby(room);
  if (room.state === 'playing') {
    socket.emit('gameStart', { map: { boxes, bounds: BOUNDS }, limit: CFG.KILL_LIMIT });
    spawnPlayer(room, p);
  }
}

io.on('connection', socket => {
  const ctx = () => {
    const room = rooms.get(where.get(socket.id));
    return room ? { room, p: room.players.get(socket.id) } : null;
  };

  socket.on('createRoom', (d, cb) => {
    if (typeof cb !== 'function') return;
    const room = { code: genCode(), hostId: socket.id, state: 'lobby', players: new Map() };
    rooms.set(room.code, room);
    joinRoom(socket, room, sanitize(d && d.name));
    cb({ ok: true, code: room.code });
  });

  socket.on('joinRoom', (d, cb) => {
    if (typeof cb !== 'function') return;
    const room = rooms.get(String((d && d.code) || '').toUpperCase().trim());
    if (!room) return cb({ ok: false, error: 'اتاقی با این کد پیدا نشد' });
    if (room.players.size >= CFG.MAX_PLAYERS) return cb({ ok: false, error: 'اتاق پر است (حداکثر ۸ نفر)' });
    joinRoom(socket, room, sanitize(d.name));
    cb({ ok: true, code: room.code });
  });

  socket.on('startGame', () => {
    const c = ctx(); if (!c || c.room.hostId !== socket.id || c.room.state !== 'lobby') return;
    const { room } = c;
    room.state = 'playing';
    for (const p of room.players.values()) { p.kills = 0; p.deaths = 0; }
    io.to(room.code).emit('gameStart', { map: { boxes, bounds: BOUNDS }, limit: CFG.KILL_LIMIT });
    for (const p of room.players.values()) spawnPlayer(room, p);
    sendLobby(room);
  });

  // موقعیت: کلاینت می‌فرستد، سرور سرعت/دیوار/مرز را اعتبارسنجی می‌کند
  socket.on('state', d => {
    const c = ctx(); if (!c || c.room.state !== 'playing' || !c.p.alive || !d) return;
    const p = c.p, now = Date.now();
    if (![d.x, d.y, d.z, d.yaw, d.pitch].every(num)) return;
    const dt = clamp((now - p.lastState) / 1000, 0.05, 0.5);
    p.lastState = now;
    const maxH = CFG.RUN * dt * 1.5 + 0.6;
    const hd = Math.hypot(d.x - p.x, d.z - p.z);
    const bad = hd > maxH || Math.abs(d.x) > BOUNDS || Math.abs(d.z) > BOUNDS || d.y < -0.01 || d.y > 40 ||
      Math.abs(d.y - p.y) > 30 * dt + 1 || inSolid(d.x, d.y, d.z);
    if (bad) { socket.emit('correct', { x: p.x, y: p.y, z: p.z }); return; }
    p.x = d.x; p.y = d.y; p.z = d.z; p.yaw = d.yaw; p.pitch = clamp(d.pitch, -1.57, 1.57);
  });

  socket.on('reload', () => { const c = ctx(); if (c && c.room.state === 'playing') startReload(c.room, c.p); });

  // شلیک: همه‌چیز (مهمات، نرخ آتش، برخورد، آسیب) در سرور محاسبه می‌شود
  socket.on('shoot', d => {
    const c = ctx(); if (!c || c.room.state !== 'playing') return;
    const { room, p } = c, now = Date.now();
    if (!p.alive || p.reloading || now - p.lastShot < CFG.FIRE_MS - 20) return;
    if (p.mag <= 0) { startReload(room, p); return; }
    p.lastShot = now; p.mag--;
    if (d && num(d.yaw) && num(d.pitch)) { p.yaw = d.yaw; p.pitch = clamp(d.pitch, -1.57, 1.57); }
    const cp = Math.cos(p.pitch), sp = () => (Math.random() - 0.5) * 0.012;
    let dir = [-Math.sin(p.yaw) * cp + sp(), Math.sin(p.pitch) + sp(), -Math.cos(p.yaw) * cp + sp()];
    const len = Math.hypot(...dir); dir = dir.map(v => v / len);
    const o = [p.x, p.y + CFG.EYE, p.z];
    let tBest = 100, victim = null, hitY = 0;
    for (const s of solids) { const t = rayAABB(o, dir, [s.minx, s.miny, s.minz], [s.maxx, s.maxy, s.maxz]); if (t !== null && t < tBest) tBest = t; }
    if (dir[1] < 0) { const t = -o[1] / dir[1]; if (t > 0 && t < tBest) tBest = t; }
    for (const q of room.players.values()) {
      if (q.id === p.id || !q.alive || now < q.invulnUntil) continue;
      const R = CFG.HIT_R;
      const t = rayAABB(o, dir, [q.x - R, q.y, q.z - R], [q.x + R, q.y + CFG.HEIGHT, q.z + R]);
      if (t !== null && t < tBest) { tBest = t; victim = q; hitY = o[1] + dir[1] * t; }
    }
    const end = [o[0] + dir[0] * tBest, o[1] + dir[1] * tBest, o[2] + dir[2] * tBest];
    io.to(room.code).emit('shot', { id: p.id, f: o, t: end, h: !!victim });
    if (victim) {
      const head = hitY > victim.y + 1.42;
      victim.hp -= CFG.DMG * (head ? CFG.HEAD_MULT : 1);
      const dead = victim.hp <= 0;
      io.to(p.id).emit('hit', { head, kill: dead });
      io.to(victim.id).emit('damaged', { hp: Math.max(0, victim.hp), fx: p.x, fz: p.z });
      if (dead) {
        victim.alive = false; victim.hp = 0; victim.deaths++; p.kills++;
        clearTimeout(victim.reloadTimer);
        io.to(room.code).emit('kill', { killer: p.name, victim: victim.name, head });
        io.to(victim.id).emit('died', { by: p.name, ms: CFG.RESPAWN_MS });
        victim.respawnTimer = setTimeout(() => {
          if (room.state === 'playing' && room.players.has(victim.id)) spawnPlayer(room, victim);
        }, CFG.RESPAWN_MS);
        if (p.kills >= CFG.KILL_LIMIT) { endGame(room, p); return; }
      }
    }
    io.to(p.id).emit('ammo', { mag: p.mag, reserve: p.reserve, reloading: false });
    if (p.mag === 0) startReload(room, p);
  });

  socket.on('leaveRoom', () => removePlayer(socket.id));
  socket.on('disconnect', () => removePlayer(socket.id));
});

// ارسال وضعیت همه بازیکنان ۲۰ بار در ثانیه
setInterval(() => {
  for (const room of rooms.values()) {
    if (room.state !== 'playing') continue;
    io.to(room.code).emit('snap', {
      p: [...room.players.values()].map(p => ({
        id: p.id, n: p.name, x: +p.x.toFixed(2), y: +p.y.toFixed(2), z: +p.z.toFixed(2),
        yw: +p.yaw.toFixed(3), pt: +p.pitch.toFixed(3), hp: p.hp, a: p.alive, k: p.kills, d: p.deaths
      }))
    });
  }
}, CFG.TICK_MS);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('FPS Arena running on port ' + PORT));
